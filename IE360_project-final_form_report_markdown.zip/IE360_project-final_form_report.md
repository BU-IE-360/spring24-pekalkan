# IE 360 Spring 24' Project

## 2024-06-05

### Yaren Ezgi Işık 2019402063
### Furkan Çelen 2019402102
### Enes Furkan Pekalkan 2018402261

## Introduction

States encourage the use of environmentally friendly renewable energy sources instead of fossil fuels due to the damage they cause to the environment. Solar energy is also among the renewable energy sources. European Union funds provide funding to companies that produce solar energy. One of the biggest problems encountered when producing electrical energy is storage. Therefore, it is essential for energy efficiency to distribute the electricity produced to the regions in need as it is produced. Therefore, it is useful to forecast the electricity produced almost accurately with previous data.

Some regions in Turkey are especially rich in terms of sunlight exposure. Gedikli Solar Power Plant, located between 37.75-38.75 northern parallels and 34.45-35.5 eastern meridians in Niğde province, was established in the most sunny regions of Turkey. Managing total production, transmitting energy, and ensuring maximum efficiency are key objectives of the company. To enhance production planning, the facility seeks to determine the projected daily production for the following day. The dataset supplied by the company includes the historical hourly energy productions from “01/01/2022” to “29/05/2024”. Forecasts will be generated from “May 13-26, 2024”. The dataset used in this project includes hourly measurements of temperature, relative humidity, downward shortwave radiation flux at both the atmospheric and surface levels, snowfall status, and cloud cover for 25 different coordinates corresponding to solar plant locations. Additionally, it encompasses the hourly production data of the solar power plants.





```R
options(warn=-1) #suppress warnings
require(data.table)
require(lubridate)
require(zoo)
library(forecast)
library(tseries)
library(ggplot2)
require(urca)
library(dplyr)
library(GGally)
data_path="C:/Users/DELL/Desktop/360_proje/production_22.csv"
production = fread(data_path)
production[,date:=as.Date(date)]


# Loading and preparing data
data_path = "C:/Users/DELL/Desktop/360_proje/processed_weather.csv"
weather_info = fread(data_path)
weather_info = weather_info[complete.cases(weather_info)]
weather_info[, datetime := ymd(date) + dhours(hour)]
weather_info = weather_info[order(datetime)]

# Aggregating daily data with relevant weather metrics, grouped by date, hour, lat, lon, etc.
daily_series = weather_info[, .(
    DSWRF_surface = sum(dswrf_surface),
    TCDC_low_cloud = sum(tcdc_low.cloud.layer),
    TCDC_middle_cloud = sum(tcdc_middle.cloud.layer),
    TCDC_high_cloud = sum(tcdc_high.cloud.layer),
    TCDC_entire_atmosphere = sum(tcdc_entire.atmosphere),
    USWRF_top_of_atmosphere = sum(uswrf_top_of_atmosphere),
    CSNOW_surface = sum(csnow_surface),
    DLWRF_surface = sum(dlwrf_surface),
    USRWF_surface = sum(uswrf_surface),
    TMP_surface = sum(tmp_surface)
), by = .(date, hour, lat, lon)]

# Melting into long format, keeping 'date', 'hour', 'lat', 'lon' as id.vars
long_format = melt(daily_series, id.vars = c("date", "hour", "lat", "lon"), measure.vars = names(daily_series)[-1:-4], variable.name = "metric", value.name = "value")

# Create a new identifier for each unique combination of metric, lat, and lon
long_format[, identifier := paste(metric, lat, lon, sep = "_")]

# Reshaping into wide format with 'date' and 'hour' as keys
wide_weather = dcast(long_format, date + hour ~ identifier, value.var = "value")

# Arranging'date' and 'hour' next to each other
setcolorder(wide_weather, c("date", "hour", names(wide_weather)[-1:-2]))
dim(wide_weather)
str(wide_weather)
```

    Zorunlu paket yükleniyor: data.table
    
    Zorunlu paket yükleniyor: lubridate
    
    
    Attaching package: ‘lubridate’
    
    
    The following objects are masked from ‘package:data.table’:
    
        hour, isoweek, mday, minute, month, quarter, second, wday, week,
        yday, year
    
    
    The following objects are masked from ‘package:base’:
    
        date, intersect, setdiff, union
    
    
    Zorunlu paket yükleniyor: zoo
    
    
    Attaching package: ‘zoo’
    
    
    The following objects are masked from ‘package:data.table’:
    
        yearmon, yearqtr
    
    
    The following objects are masked from ‘package:base’:
    
        as.Date, as.Date.numeric
    
    
    Registered S3 method overwritten by 'quantmod':
      method            from
      as.zoo.data.frame zoo 
    
    Zorunlu paket yükleniyor: urca
    
    
    Attaching package: ‘dplyr’
    
    
    The following objects are masked from ‘package:data.table’:
    
        between, first, last
    
    
    The following objects are masked from ‘package:stats’:
    
        filter, lag
    
    
    The following objects are masked from ‘package:base’:
    
        intersect, setdiff, setequal, union
    
    
    Registered S3 method overwritten by 'GGally':
      method from   
      +.gg   ggplot2
    
    


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>21106</li><li>252</li></ol>



    Classes ‘data.table’ and 'data.frame':	21106 obs. of  252 variables:
     $ date                               : IDate, format: "2022-01-01" "2022-01-01" ...
     $ hour                               : int  4 5 6 7 8 9 10 11 12 13 ...
     $ CSNOW_surface_37.75_34.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_34.75          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_35             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_35.25          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_35.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_34.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_34.75          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_35             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_35.25          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_35.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_34.5            : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_34.75           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_35              : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_35.25           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_35.5            : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_34.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_34.75          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_35             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_35.25          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_35.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_34.5              : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_34.75             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_35                : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_35.25             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_35.5              : num  0 0 0 0 0 0 0 0 0 0 ...
     $ DLWRF_surface_37.75_34.5           : num  242 241 240 239 239 ...
     $ DLWRF_surface_37.75_34.75          : num  227 226 226 225 225 ...
     $ DLWRF_surface_37.75_35             : num  217 215 214 214 214 ...
     $ DLWRF_surface_37.75_35.25          : num  215 214 213 213 213 ...
     $ DLWRF_surface_37.75_35.5           : num  236 235 235 235 234 ...
     $ DLWRF_surface_38.25_34.5           : num  228 228 228 228 228 ...
     $ DLWRF_surface_38.25_34.75          : num  231 231 231 231 231 ...
     $ DLWRF_surface_38.25_35             : num  231 231 231 231 232 ...
     $ DLWRF_surface_38.25_35.25          : num  233 233 233 233 233 ...
     $ DLWRF_surface_38.25_35.5           : num  223 223 223 223 223 ...
     $ DLWRF_surface_38.5_34.5            : num  234 234 234 235 235 ...
     $ DLWRF_surface_38.5_34.75           : num  230 230 230 230 231 ...
     $ DLWRF_surface_38.5_35              : num  228 229 229 229 230 ...
     $ DLWRF_surface_38.5_35.25           : num  227 228 228 229 230 ...
     $ DLWRF_surface_38.5_35.5            : num  212 212 212 214 217 ...
     $ DLWRF_surface_38.75_34.5           : num  242 242 242 243 244 ...
     $ DLWRF_surface_38.75_34.75          : num  240 240 240 241 241 ...
     $ DLWRF_surface_38.75_35             : num  236 236 237 238 238 ...
     $ DLWRF_surface_38.75_35.25          : num  234 234 235 236 237 ...
     $ DLWRF_surface_38.75_35.5           : num  232 233 234 237 238 ...
     $ DLWRF_surface_38_34.5              : num  226 226 226 226 226 ...
     $ DLWRF_surface_38_34.75             : num  225 225 225 225 225 ...
     $ DLWRF_surface_38_35                : num  219 219 219 219 220 ...
     $ DLWRF_surface_38_35.25             : num  209 209 210 210 210 ...
     $ DLWRF_surface_38_35.5              : num  222 222 222 222 222 ...
     $ DSWRF_surface_37.75_34.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_34.75          : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_35             : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_35.25          : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_35.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_34.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_34.75          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_35             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_35.25          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_35.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_34.5            : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_34.75           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_35              : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_35.25           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_35.5            : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_34.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_34.75          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_35             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_35.25          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_35.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_34.5              : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_34.75             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_35                : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_35.25             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_35.5              : num  0 0 0 0 0 ...
     $ TCDC_entire_atmosphere_37.75_34.5  : num  41.4 29.6 28.3 32.2 32.5 43.2 95.5 71.2 55.6 48.9 ...
     $ TCDC_entire_atmosphere_37.75_34.75 : num  32.7 25.5 22.8 22.1 24.4 31.8 92.8 63.8 54.1 45.3 ...
     $ TCDC_entire_atmosphere_37.75_35    : num  32.3 23.9 23.6 21.7 22.8 24.3 88.8 56.9 47.5 44.3 ...
     $ TCDC_entire_atmosphere_37.75_35.25 : num  21.7 16.3 14.3 18.9 24.3 24.4 68 56.5 45.6 41.8 ...
     $ TCDC_entire_atmosphere_37.75_35.5  : num  28 17.3 14.3 13.9 14.5 15.4 21.9 36.1 38.1 47.4 ...
     $ TCDC_entire_atmosphere_38.25_34.5  : num  13.2 34.4 33 44.1 46.1 54.3 37.7 38.7 48.1 61.2 ...
     $ TCDC_entire_atmosphere_38.25_34.75 : num  9.1 27 26.9 40.2 40.6 50.5 66.8 49.6 56.3 67.2 ...
     $ TCDC_entire_atmosphere_38.25_35    : num  1.7 6.2 10.6 28.5 39.4 49.5 100 77 76.1 82 ...
     $ TCDC_entire_atmosphere_38.25_35.25 : num  4 8.2 9.5 17.8 25.8 33.1 100 70.4 54.9 47.3 ...
     $ TCDC_entire_atmosphere_38.25_35.5  : num  5.2 10.3 9.4 12.2 23.8 36.4 100 99.8 75.9 63.9 ...
     $ TCDC_entire_atmosphere_38.5_34.5   : num  12.5 34 40.6 49.2 57.3 64.4 66.1 73.6 82.4 86.8 ...
     $ TCDC_entire_atmosphere_38.5_34.75  : num  11.4 23.9 23.3 37.2 42.7 52.3 76.8 72.8 79.7 84.8 ...
     $ TCDC_entire_atmosphere_38.5_35     : num  8.8 13.3 15.8 30.6 39.7 49.8 98.7 74.3 76.4 81.8 ...
     $ TCDC_entire_atmosphere_38.5_35.25  : num  3.3 9.3 13.2 30.8 41.2 51 100 68 56.1 51.7 ...
     $ TCDC_entire_atmosphere_38.5_35.5   : num  0 4.5 9.1 29.6 43.3 52.5 100 98.4 89.1 85.5 ...
     $ TCDC_entire_atmosphere_38.75_34.5  : num  14.7 34.4 44.1 54.4 62.3 68.6 82.4 91.2 94.1 94 ...
     $ TCDC_entire_atmosphere_38.75_34.75 : num  15.7 26.2 26.8 41.8 51.3 59.5 77.7 85.7 89.7 92.3 ...
     $ TCDC_entire_atmosphere_38.75_35    : num  18.3 22 27 43.8 52 60 96.8 93.2 93.8 95.4 ...
     $ TCDC_entire_atmosphere_38.75_35.25 : num  10.6 16.9 24.3 40.8 48.6 57.2 100 95.4 92.5 94.4 ...
     $ TCDC_entire_atmosphere_38.75_35.5  : num  6.7 12.5 32.3 49.2 58.4 65.3 100 96.7 89.2 87 ...
     $ TCDC_entire_atmosphere_38_34.5     : num  14 29.1 35.6 46 46.6 54.3 73.7 74.3 75.4 80.6 ...
     $ TCDC_entire_atmosphere_38_34.75    : num  15.1 14.9 19.6 32.1 35.6 44.5 94.5 74.4 73.7 78.3 ...
      [list output truncated]
     - attr(*, ".internal.selfref")=<externalptr> 
     - attr(*, "sorted")= chr [1:2] "date" "hour"
    


```R
#Putting together wide form of weather and production data
data =merge(wide_weather,production,by = c('date','hour'),all.x =T)
data <- data[order(date,hour)]
str(data)
data
```

    Classes ‘data.table’ and 'data.frame':	21106 obs. of  253 variables:
     $ date                               : IDate, format: "2022-01-01" "2022-01-01" ...
     $ hour                               : int  4 5 6 7 8 9 10 11 12 13 ...
     $ CSNOW_surface_37.75_34.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_34.75          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_35             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_35.25          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_37.75_35.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_34.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_34.75          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_35             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_35.25          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.25_35.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_34.5            : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_34.75           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_35              : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_35.25           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.5_35.5            : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_34.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_34.75          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_35             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_35.25          : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38.75_35.5           : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_34.5              : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_34.75             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_35                : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_35.25             : num  0 0 0 0 0 0 0 0 0 0 ...
     $ CSNOW_surface_38_35.5              : num  0 0 0 0 0 0 0 0 0 0 ...
     $ DLWRF_surface_37.75_34.5           : num  242 241 240 239 239 ...
     $ DLWRF_surface_37.75_34.75          : num  227 226 226 225 225 ...
     $ DLWRF_surface_37.75_35             : num  217 215 214 214 214 ...
     $ DLWRF_surface_37.75_35.25          : num  215 214 213 213 213 ...
     $ DLWRF_surface_37.75_35.5           : num  236 235 235 235 234 ...
     $ DLWRF_surface_38.25_34.5           : num  228 228 228 228 228 ...
     $ DLWRF_surface_38.25_34.75          : num  231 231 231 231 231 ...
     $ DLWRF_surface_38.25_35             : num  231 231 231 231 232 ...
     $ DLWRF_surface_38.25_35.25          : num  233 233 233 233 233 ...
     $ DLWRF_surface_38.25_35.5           : num  223 223 223 223 223 ...
     $ DLWRF_surface_38.5_34.5            : num  234 234 234 235 235 ...
     $ DLWRF_surface_38.5_34.75           : num  230 230 230 230 231 ...
     $ DLWRF_surface_38.5_35              : num  228 229 229 229 230 ...
     $ DLWRF_surface_38.5_35.25           : num  227 228 228 229 230 ...
     $ DLWRF_surface_38.5_35.5            : num  212 212 212 214 217 ...
     $ DLWRF_surface_38.75_34.5           : num  242 242 242 243 244 ...
     $ DLWRF_surface_38.75_34.75          : num  240 240 240 241 241 ...
     $ DLWRF_surface_38.75_35             : num  236 236 237 238 238 ...
     $ DLWRF_surface_38.75_35.25          : num  234 234 235 236 237 ...
     $ DLWRF_surface_38.75_35.5           : num  232 233 234 237 238 ...
     $ DLWRF_surface_38_34.5              : num  226 226 226 226 226 ...
     $ DLWRF_surface_38_34.75             : num  225 225 225 225 225 ...
     $ DLWRF_surface_38_35                : num  219 219 219 219 220 ...
     $ DLWRF_surface_38_35.25             : num  209 209 210 210 210 ...
     $ DLWRF_surface_38_35.5              : num  222 222 222 222 222 ...
     $ DSWRF_surface_37.75_34.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_34.75          : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_35             : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_35.25          : num  0 0 0 0 0 ...
     $ DSWRF_surface_37.75_35.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_34.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_34.75          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_35             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_35.25          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.25_35.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_34.5            : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_34.75           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_35              : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_35.25           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.5_35.5            : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_34.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_34.75          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_35             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_35.25          : num  0 0 0 0 0 ...
     $ DSWRF_surface_38.75_35.5           : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_34.5              : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_34.75             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_35                : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_35.25             : num  0 0 0 0 0 ...
     $ DSWRF_surface_38_35.5              : num  0 0 0 0 0 ...
     $ TCDC_entire_atmosphere_37.75_34.5  : num  41.4 29.6 28.3 32.2 32.5 43.2 95.5 71.2 55.6 48.9 ...
     $ TCDC_entire_atmosphere_37.75_34.75 : num  32.7 25.5 22.8 22.1 24.4 31.8 92.8 63.8 54.1 45.3 ...
     $ TCDC_entire_atmosphere_37.75_35    : num  32.3 23.9 23.6 21.7 22.8 24.3 88.8 56.9 47.5 44.3 ...
     $ TCDC_entire_atmosphere_37.75_35.25 : num  21.7 16.3 14.3 18.9 24.3 24.4 68 56.5 45.6 41.8 ...
     $ TCDC_entire_atmosphere_37.75_35.5  : num  28 17.3 14.3 13.9 14.5 15.4 21.9 36.1 38.1 47.4 ...
     $ TCDC_entire_atmosphere_38.25_34.5  : num  13.2 34.4 33 44.1 46.1 54.3 37.7 38.7 48.1 61.2 ...
     $ TCDC_entire_atmosphere_38.25_34.75 : num  9.1 27 26.9 40.2 40.6 50.5 66.8 49.6 56.3 67.2 ...
     $ TCDC_entire_atmosphere_38.25_35    : num  1.7 6.2 10.6 28.5 39.4 49.5 100 77 76.1 82 ...
     $ TCDC_entire_atmosphere_38.25_35.25 : num  4 8.2 9.5 17.8 25.8 33.1 100 70.4 54.9 47.3 ...
     $ TCDC_entire_atmosphere_38.25_35.5  : num  5.2 10.3 9.4 12.2 23.8 36.4 100 99.8 75.9 63.9 ...
     $ TCDC_entire_atmosphere_38.5_34.5   : num  12.5 34 40.6 49.2 57.3 64.4 66.1 73.6 82.4 86.8 ...
     $ TCDC_entire_atmosphere_38.5_34.75  : num  11.4 23.9 23.3 37.2 42.7 52.3 76.8 72.8 79.7 84.8 ...
     $ TCDC_entire_atmosphere_38.5_35     : num  8.8 13.3 15.8 30.6 39.7 49.8 98.7 74.3 76.4 81.8 ...
     $ TCDC_entire_atmosphere_38.5_35.25  : num  3.3 9.3 13.2 30.8 41.2 51 100 68 56.1 51.7 ...
     $ TCDC_entire_atmosphere_38.5_35.5   : num  0 4.5 9.1 29.6 43.3 52.5 100 98.4 89.1 85.5 ...
     $ TCDC_entire_atmosphere_38.75_34.5  : num  14.7 34.4 44.1 54.4 62.3 68.6 82.4 91.2 94.1 94 ...
     $ TCDC_entire_atmosphere_38.75_34.75 : num  15.7 26.2 26.8 41.8 51.3 59.5 77.7 85.7 89.7 92.3 ...
     $ TCDC_entire_atmosphere_38.75_35    : num  18.3 22 27 43.8 52 60 96.8 93.2 93.8 95.4 ...
     $ TCDC_entire_atmosphere_38.75_35.25 : num  10.6 16.9 24.3 40.8 48.6 57.2 100 95.4 92.5 94.4 ...
     $ TCDC_entire_atmosphere_38.75_35.5  : num  6.7 12.5 32.3 49.2 58.4 65.3 100 96.7 89.2 87 ...
     $ TCDC_entire_atmosphere_38_34.5     : num  14 29.1 35.6 46 46.6 54.3 73.7 74.3 75.4 80.6 ...
     $ TCDC_entire_atmosphere_38_34.75    : num  15.1 14.9 19.6 32.1 35.6 44.5 94.5 74.4 73.7 78.3 ...
      [list output truncated]
     - attr(*, ".internal.selfref")=<externalptr> 
     - attr(*, "sorted")= chr [1:2] "date" "hour"
    


<table class="dataframe">
<caption>A data.table: 21106 × 253</caption>
<thead>
	<tr><th scope=col>date</th><th scope=col>hour</th><th scope=col>CSNOW_surface_37.75_34.5</th><th scope=col>CSNOW_surface_37.75_34.75</th><th scope=col>CSNOW_surface_37.75_35</th><th scope=col>CSNOW_surface_37.75_35.25</th><th scope=col>CSNOW_surface_37.75_35.5</th><th scope=col>CSNOW_surface_38.25_34.5</th><th scope=col>CSNOW_surface_38.25_34.75</th><th scope=col>CSNOW_surface_38.25_35</th><th scope=col>⋯</th><th scope=col>USWRF_top_of_atmosphere_38.75_34.75</th><th scope=col>USWRF_top_of_atmosphere_38.75_35</th><th scope=col>USWRF_top_of_atmosphere_38.75_35.25</th><th scope=col>USWRF_top_of_atmosphere_38.75_35.5</th><th scope=col>USWRF_top_of_atmosphere_38_34.5</th><th scope=col>USWRF_top_of_atmosphere_38_34.75</th><th scope=col>USWRF_top_of_atmosphere_38_35</th><th scope=col>USWRF_top_of_atmosphere_38_35.25</th><th scope=col>USWRF_top_of_atmosphere_38_35.5</th><th scope=col>production</th></tr>
	<tr><th scope=col>&lt;IDate&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>⋯</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>2022-01-01</td><td> 4</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td> 5</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td> 6</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td> 7</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td> 8</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>3.40</td></tr>
	<tr><td>2022-01-01</td><td> 9</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  8.096</td><td>  8.592</td><td>  8.848</td><td>  8.704</td><td>  9.104</td><td>  8.624</td><td>  9.552</td><td> 10.512</td><td> 10.272</td><td>6.80</td></tr>
	<tr><td>2022-01-01</td><td>10</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>105.264</td><td>120.656</td><td>137.664</td><td>142.336</td><td>133.104</td><td>132.960</td><td>162.352</td><td>179.808</td><td>177.152</td><td>9.38</td></tr>
	<tr><td>2022-01-01</td><td>11</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>127.472</td><td>130.512</td><td>142.112</td><td>147.088</td><td>160.240</td><td>148.576</td><td>182.608</td><td>210.560</td><td>212.928</td><td>7.65</td></tr>
	<tr><td>2022-01-01</td><td>12</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>141.328</td><td>140.320</td><td>150.656</td><td>150.096</td><td>179.024</td><td>165.360</td><td>201.632</td><td>234.480</td><td>234.352</td><td>6.80</td></tr>
	<tr><td>2022-01-01</td><td>13</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>157.712</td><td>161.376</td><td>168.096</td><td>154.944</td><td>195.552</td><td>177.776</td><td>213.792</td><td>251.424</td><td>248.272</td><td>5.10</td></tr>
	<tr><td>2022-01-01</td><td>14</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>165.664</td><td>167.312</td><td>173.920</td><td>163.232</td><td>201.872</td><td>183.472</td><td>217.664</td><td>259.952</td><td>253.232</td><td>5.10</td></tr>
	<tr><td>2022-01-01</td><td>15</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>172.560</td><td>171.136</td><td>177.088</td><td>168.960</td><td>204.096</td><td>183.040</td><td>215.136</td><td>259.856</td><td>249.712</td><td>1.70</td></tr>
	<tr><td>2022-01-01</td><td>16</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>167.856</td><td>165.584</td><td>149.936</td><td>148.976</td><td>186.688</td><td>151.424</td><td>167.536</td><td>219.200</td><td>185.264</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td>17</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>138.080</td><td>133.008</td><td>120.208</td><td>114.304</td><td>148.992</td><td>121.104</td><td>130.736</td><td>165.504</td><td>141.408</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td>18</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td> 95.632</td><td> 91.904</td><td> 82.928</td><td> 78.464</td><td>104.016</td><td> 84.560</td><td> 90.816</td><td>113.904</td><td> 97.232</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td>19</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td> 71.728</td><td> 68.928</td><td> 62.192</td><td> 58.848</td><td> 78.000</td><td> 63.424</td><td> 68.096</td><td> 85.424</td><td> 72.912</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td>20</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td> 57.376</td><td> 55.152</td><td> 49.760</td><td> 47.072</td><td> 62.416</td><td> 50.736</td><td> 54.480</td><td> 68.336</td><td> 58.336</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td>21</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td> 47.808</td><td> 45.952</td><td> 41.472</td><td> 39.232</td><td> 52.000</td><td> 42.288</td><td> 45.392</td><td> 56.944</td><td> 48.624</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td>22</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-01</td><td>23</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 2</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 3</td><td>0</td><td>1</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 4</td><td>0</td><td>1</td><td>1</td><td>1</td><td>0</td><td>1</td><td>1</td><td>1</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 5</td><td>0</td><td>1</td><td>1</td><td>1</td><td>0</td><td>1</td><td>1</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 6</td><td>0</td><td>1</td><td>1</td><td>1</td><td>0</td><td>1</td><td>1</td><td>1</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 7</td><td>0</td><td>1</td><td>1</td><td>1</td><td>0</td><td>1</td><td>1</td><td>1</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 8</td><td>0</td><td>1</td><td>1</td><td>1</td><td>0</td><td>1</td><td>1</td><td>1</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>0.00</td></tr>
	<tr><td>2022-01-02</td><td> 9</td><td>0</td><td>1</td><td>1</td><td>1</td><td>0</td><td>1</td><td>1</td><td>1</td><td>⋯</td><td> 12.208</td><td> 12.816</td><td> 13.232</td><td> 13.648</td><td> 13.200</td><td> 13.696</td><td> 13.696</td><td> 13.856</td><td> 14.288</td><td>0.85</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋱</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>2024-05-28</td><td>16</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>596.352</td><td>593.072</td><td>505.456</td><td>340.544</td><td>176.544</td><td>178.304</td><td>339.328</td><td>543.552</td><td>567.568</td><td>NA</td></tr>
	<tr><td>2024-05-28</td><td>17</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>564.576</td><td>570.432</td><td>521.616</td><td>440.320</td><td>176.992</td><td>178.864</td><td>353.776</td><td>498.128</td><td>463.120</td><td>NA</td></tr>
	<tr><td>2024-05-28</td><td>18</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>462.976</td><td>504.208</td><td>479.792</td><td>416.832</td><td>168.032</td><td>166.704</td><td>336.304</td><td>468.352</td><td>370.832</td><td>NA</td></tr>
	<tr><td>2024-05-28</td><td>19</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>372.960</td><td>407.840</td><td>402.080</td><td>345.744</td><td>152.848</td><td>151.472</td><td>288.928</td><td>404.640</td><td>329.344</td><td>NA</td></tr>
	<tr><td>2024-05-28</td><td>20</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>305.104</td><td>332.944</td><td>327.904</td><td>282.464</td><td>129.040</td><td>128.608</td><td>238.032</td><td>331.232</td><td>271.920</td><td>NA</td></tr>
	<tr><td>2024-05-28</td><td>21</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>254.256</td><td>277.456</td><td>273.248</td><td>235.392</td><td>107.536</td><td>107.184</td><td>198.368</td><td>276.032</td><td>226.592</td><td>NA</td></tr>
	<tr><td>2024-05-28</td><td>22</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-28</td><td>23</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 2</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 3</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 4</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 5</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>  0.000</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 6</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>  5.200</td><td>  5.504</td><td>  5.680</td><td>  5.856</td><td>  4.352</td><td>  4.624</td><td>  4.944</td><td>  5.312</td><td>  8.192</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 7</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td> 25.328</td><td> 25.744</td><td> 25.312</td><td> 26.992</td><td> 23.296</td><td> 23.936</td><td> 24.320</td><td> 25.072</td><td> 32.336</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 8</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td> 46.944</td><td> 47.280</td><td> 45.840</td><td> 46.544</td><td> 43.680</td><td> 44.640</td><td> 44.720</td><td> 45.760</td><td> 52.256</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td> 9</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td> 66.240</td><td> 66.432</td><td> 63.904</td><td> 63.328</td><td> 61.824</td><td> 63.072</td><td> 62.752</td><td> 63.824</td><td> 69.248</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>10</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>180.944</td><td>180.048</td><td>170.272</td><td>160.912</td><td>169.184</td><td>172.272</td><td>169.040</td><td>168.320</td><td>156.480</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>11</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>186.432</td><td>185.392</td><td>174.992</td><td>165.184</td><td>174.192</td><td>177.440</td><td>174.432</td><td>184.928</td><td>160.672</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>12</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>190.240</td><td>189.056</td><td>178.240</td><td>168.144</td><td>177.664</td><td>181.120</td><td>193.040</td><td>288.848</td><td>165.952</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>13</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>192.704</td><td>191.392</td><td>180.288</td><td>170.048</td><td>179.824</td><td>186.960</td><td>282.544</td><td>428.272</td><td>176.144</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>14</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>193.904</td><td>192.480</td><td>181.248</td><td>171.776</td><td>180.832</td><td>210.032</td><td>376.064</td><td>512.240</td><td>257.616</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>15</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>193.808</td><td>192.288</td><td>184.976</td><td>207.840</td><td>180.752</td><td>226.368</td><td>389.360</td><td>526.432</td><td>286.320</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>16</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>183.488</td><td>181.696</td><td>171.776</td><td>388.992</td><td>171.856</td><td>283.312</td><td>360.048</td><td>178.096</td><td>174.016</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>17</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>175.424</td><td>173.728</td><td>164.512</td><td>277.664</td><td>196.816</td><td>246.048</td><td>271.440</td><td>168.720</td><td>197.136</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>18</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>213.536</td><td>163.216</td><td>166.160</td><td>228.336</td><td>217.296</td><td>232.800</td><td>233.968</td><td>159.232</td><td>204.304</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>19</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>199.376</td><td>148.592</td><td>153.904</td><td>200.992</td><td>205.552</td><td>216.416</td><td>208.320</td><td>143.312</td><td>177.040</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>20</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>169.360</td><td>125.504</td><td>129.264</td><td>166.592</td><td>173.072</td><td>182.800</td><td>174.704</td><td>120.496</td><td>147.168</td><td>NA</td></tr>
	<tr><td>2024-05-29</td><td>21</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>141.120</td><td>104.592</td><td>107.728</td><td>138.832</td><td>144.224</td><td>152.336</td><td>145.584</td><td>100.416</td><td>122.640</td><td>NA</td></tr>
</tbody>
</table>



### Hourly Production Plots


```R
train_start=as.Date('2022-01-02')
test_start= as.Date('2024-02-01')
test_end = as.Date('2024-05-20')
ggplot(data[date>=train_start],aes(x=date,y=production,col=hour))+geom_line()+facet_wrap(~hour)+theme(axis.text.x=element_text(angle=70, hjust=1.4, vjust = 1.4))
```


    
![png](output_8_0.png)
    


The above figure depicts hourly solar power production across various times of the day from 2022 to 2024. The x-axis represents the date range, while the y-axis shows production levels. Each panel corresponds to a specific hour of the day. The graph clearly demonstrates that there is no production from 19:00 to 4:00. Additionally, there is a noticeable seasonal pattern, with higher production levels observed during daylight hours and reduced production during the winter months, reflecting the impact of shorter daylight periods on solar power generation.


### Daily Production Plot


```R
daily_series=data[,list(total=mean(production)),list(date)]
ggplot(daily_series,aes(x=date,y=total))+geom_line()

```


    
![png](output_11_0.png)
    


The graph above depicts daily solar power production from 2022 to 2024. The x-axis represents the date range, while the y-axis shows the total production levels. The data shows production levels ranging from approximately 0 to over 4. There is a clear seasonal pattern, with production peaking in the summer months and declining in the winter months. The variability within each year, with peaks and troughs, suggests changes in weather conditions, solar irradiance, and possibly maintenance activities. This indicates the need for a more stable and smooth production model to handle these fluctuations better.


### Partial Autocorrelation and Autocorrelation of Hourly Production


```R
acf(na.omit(data$production),lag.max = 60)
pacf(na.omit(data$production),lag.max = 60)
```


    
![png](output_14_0.png)
    



    
![png](output_14_1.png)
    


The first figure above represents the Autocorrelation Function (ACF) of the solar power production data. Significant spikes at certain lags, especially at lag 24, indicate a strong daily seasonality in the data. This implies that production at a given hour is highly correlated with the production at the same hour on the previous day.
 The second figure illustrates the Partial Autocorrelation Function (PACF) of the dataset. The spikes at lag 1 and lag 25 suggest that the immediate past hour and the same hour on the previous day have significant direct impacts on the current production values.
Both figures confirm the presence of daily patterns in solar power production, with strong correlations observed at 24-hour intervals. This indicates that the production levels are influenced by consistent daily cycles, likely driven by solar irradiance and environmental conditions that follow a daily rhythm.


### Modeling Approaches

### 1) Linear Regression and Time Series Regression

Given the seasonal behaviour of the data (hourly, monthly, and seasonally), using weather data with time-related regressors is an effective approach. Models are developed step by step by adding regressors, and their performance is measured using adjusted R-squared and residual plots. Due to the large number of rows in the weather data, it is averaged over 25 coordinates, and a ggpairs plot is created to analyze the regressors more effectively. These models forecast from 06:00 to 18:00 because there is no significant production outside these hours, making it unnecessary to predict for those times.


#### 1.a Model with Averaged Data


```R
avgdata=data.table(date=data$date,hour=data$hour,CSNOW=rowSums(data[,3:27])/25,DLWRF=rowSums(data[,28:52])/25,DSWRF=rowSums(data[,53:77])/25,TCDC_ENTIRE=rowSums(data[,78:102])/25,TCDC_High_Cloud=rowSums(data[,103:127])/25,TCDC_Low_Cloud=rowSums(data[,128:152])/25,TCDC_Middle_Cloud=rowSums(data[,153:177])/25,TMP_surface=rowSums(data[,178:202])/25,USRWF_surface=rowSums(data[,203:227])/25,USWRF_top_of_atmosphere=rowSums(data[,228:252])/25,production=data$production,month=as.numeric(format(data$date,format="%m")))

avgweather=data.table(date=wide_weather$date,hour=wide_weather$hour,CSNOW=rowSums(data[,3:27])/25,DLWRF=rowSums(data[,28:52])/25,DSWRF=rowSums(data[,53:77])/25,TCDC_ENTIRE=rowSums(data[,78:102])/25,TCDC_High_Cloud=rowSums(data[,103:127])/25,TCDC_Low_Cloud=rowSums(data[,128:152])/25,TCDC_Middle_Cloud=rowSums(data[,153:177])/25,TMP_surface=rowSums(data[,178:202])/25,USRWF_surface=rowSums(data[,203:227])/25,USWRF_top_of_atmosphere=rowSums(data[,228:252])/25)
#avgweather

model_avg = lm(production~.-date-hour-month-production,avgdata[hour>=6 & hour <=18])
ggpairs(avgdata)
```


    
![png](output_20_0.png)
    



```R
summary(model_avg)
```


    
    Call:
    lm(formula = production ~ . - date - hour - month - production, 
        data = avgdata[hour >= 6 & hour <= 18])
    
    Residuals:
         Min       1Q   Median       3Q      Max 
    -10.1002  -1.9363  -0.1002   1.8793   9.6434 
    
    Coefficients:
                              Estimate Std. Error t value Pr(>|t|)    
    (Intercept)             -1.137e+02  1.629e+00 -69.836  < 2e-16 ***
    CSNOW                   -6.350e-01  2.023e-01  -3.139  0.00170 ** 
    DLWRF                   -9.919e-02  1.477e-03 -67.162  < 2e-16 ***
    DSWRF                   -7.474e-03  2.625e-04 -28.474  < 2e-16 ***
    TCDC_ENTIRE             -2.674e-03  1.847e-03  -1.447  0.14780    
    TCDC_High_Cloud          7.781e-03  1.495e-03   5.205 1.97e-07 ***
    TCDC_Low_Cloud           4.028e-02  1.944e-03  20.723  < 2e-16 ***
    TCDC_Middle_Cloud        9.981e-03  1.389e-03   7.187 7.06e-13 ***
    TMP_surface              5.103e-01  6.879e-03  74.177  < 2e-16 ***
    USRWF_surface            9.937e-03  8.450e-04  11.759  < 2e-16 ***
    USWRF_top_of_atmosphere  1.069e-03  3.936e-04   2.716  0.00662 ** 
    ---
    Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
    
    Residual standard error: 2.682 on 11360 degrees of freedom
      (66 observations deleted due to missingness)
    Multiple R-squared:  0.5157,	Adjusted R-squared:  0.5153 
    F-statistic:  1210 on 10 and 11360 DF,  p-value: < 2.2e-16
    


#### Residual Plots of The Only Averaged Data Model


```R
checkresiduals(model_avg)
```


    
    	Breusch-Godfrey test for serial correlation of order up to 14
    
    data:  Residuals
    LM test = 7679.4, df = 14, p-value < 2.2e-16
    



    
![png](output_23_1.png)
    


The residual plots for the linear regression model incorporating month and hour as factors reveal important insights. The residuals appear to be randomly distributed around zero, suggesting that the model has captured the overall trend in the data. The Autocorrelation Function (ACF) plot shows significant spikes at certain lags, indicating some remaining autocorrelation in the residuals. This suggests that while the model accounts for much of the variation in the production data, there are still patterns that still need to be fully captured. The residuals' partial autocorrelation function (PACF) plot further supports this, with noticeable correlations at various lags. Despite the model's effectiveness, the residuals' histogram shows a roughly normal distribution but with some skewness, indicating that the model might benefit from further refinement or the inclusion of additional predictors to capture the underlying patterns in the data fully.


#### 1.b Model with Averaged Data + Time Related Regressors (Hour and Month)


```R
#Month and hour is added as a model

model_avg_time = lm(production~.-date-hour-month+as.factor(month)+as.factor(hour)-production,avgdata[hour>=7 & hour <=18])
summary(model_avg_time)
checkresiduals(model_avg_time) 
pacf(model_avg_time$residuals)

```


    
    Call:
    lm(formula = production ~ . - date - hour - month + as.factor(month) + 
        as.factor(hour) - production, data = avgdata[hour >= 7 & 
        hour <= 18])
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -9.3416 -1.2034  0.1733  1.2960  8.6601 
    
    Coefficients:
                              Estimate Std. Error t value Pr(>|t|)    
    (Intercept)             -4.060e+01  2.015e+00 -20.153  < 2e-16 ***
    CSNOW                   -7.032e-01  1.586e-01  -4.433 9.39e-06 ***
    DLWRF                   -2.940e-02  1.622e-03 -18.125  < 2e-16 ***
    DSWRF                   -2.182e-03  3.166e-04  -6.892 5.81e-12 ***
    TCDC_ENTIRE             -7.794e-03  1.463e-03  -5.326 1.02e-07 ***
    TCDC_High_Cloud         -1.524e-03  1.177e-03  -1.295 0.195302    
    TCDC_Low_Cloud          -3.968e-03  1.601e-03  -2.478 0.013226 *  
    TCDC_Middle_Cloud       -1.154e-03  1.095e-03  -1.054 0.291963    
    TMP_surface              1.846e-01  8.426e-03  21.904  < 2e-16 ***
    USRWF_surface            5.419e-03  7.563e-04   7.166 8.23e-13 ***
    USWRF_top_of_atmosphere  2.131e-03  5.555e-04   3.836 0.000126 ***
    as.factor(month)2        1.029e+00  9.437e-02  10.899  < 2e-16 ***
    as.factor(month)3        1.076e+00  1.140e-01   9.443  < 2e-16 ***
    as.factor(month)4        6.409e-01  1.456e-01   4.403 1.08e-05 ***
    as.factor(month)5        7.970e-01  1.632e-01   4.883 1.06e-06 ***
    as.factor(month)6        8.390e-01  1.834e-01   4.574 4.84e-06 ***
    as.factor(month)7        6.900e-01  1.971e-01   3.500 0.000466 ***
    as.factor(month)8        9.890e-02  2.126e-01   0.465 0.641841    
    as.factor(month)9        2.028e-01  1.754e-01   1.156 0.247773    
    as.factor(month)10       2.461e-01  1.313e-01   1.874 0.060947 .  
    as.factor(month)11      -4.655e-02  1.056e-01  -0.441 0.659422    
    as.factor(month)12       2.961e-02  9.734e-02   0.304 0.760979    
    as.factor(hour)8         2.073e+00  9.862e-02  21.018  < 2e-16 ***
    as.factor(hour)9         3.176e+00  1.163e-01  27.306  < 2e-16 ***
    as.factor(hour)10        3.198e+00  2.110e-01  15.155  < 2e-16 ***
    as.factor(hour)11        2.814e+00  2.371e-01  11.867  < 2e-16 ***
    as.factor(hour)12        2.449e+00  2.560e-01   9.567  < 2e-16 ***
    as.factor(hour)13        2.000e+00  2.666e-01   7.504 6.67e-14 ***
    as.factor(hour)14        1.106e+00  2.688e-01   4.114 3.92e-05 ***
    as.factor(hour)15       -3.736e-01  2.634e-01  -1.418 0.156092    
    as.factor(hour)16       -1.920e+00  2.272e-01  -8.451  < 2e-16 ***
    as.factor(hour)17       -2.942e+00  1.974e-01 -14.901  < 2e-16 ***
    as.factor(hour)18       -3.173e+00  1.671e-01 -18.986  < 2e-16 ***
    ---
    Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
    
    Residual standard error: 1.97 on 10463 degrees of freedom
      (61 observations deleted due to missingness)
    Multiple R-squared:  0.7329,	Adjusted R-squared:  0.732 
    F-statistic: 896.9 on 32 and 10463 DF,  p-value: < 2.2e-16
    



    
    	Breusch-Godfrey test for serial correlation of order up to 36
    
    data:  Residuals
    LM test = 4739.8, df = 36, p-value < 2.2e-16
    



    
![png](output_26_2.png)
    



    
![png](output_26_3.png)
    


#### Residual plots of the averaged data+time related regressors (hour and month) model




```R
checkresiduals(model_avg_time)

```


    
    	Breusch-Godfrey test for serial correlation of order up to 36
    
    data:  Residuals
    LM test = 4739.8, df = 36, p-value < 2.2e-16
    



    
![png](output_28_1.png)
    


The residual plot for the linear regression model with month and time as factors provides important insights. The residuals appear to be randomly distributed around zero, indicating that the model is capturing the overall trends in the data. The ACF (Autocorrelation Function) plot shows prominent peaks at certain lags, indicating that there remains autocorrelation in the residuals. This suggests that while the model explains much of the variation in the production data, there are  patterns that have not yet been fully captured. The PACF (Partial Autocorrelation Function) plot of the residuals further supports this, showing significant correlation at various lags. Despite the validity of the model, the histogram of the residuals shows an approximately normal distribution, albeit with some skewness, suggesting that the model may benefit from further refinement or the inclusion of additional predictors to fully capture the underlying patterns in the data.



### PACF plot of the residuals




```R
pacf(model_avg_time$residuals) # pacf analysis of residuals

```


    
![png](output_31_0.png)
    


The two largest correlations are at lag 1 and lag 12. Since this model is only applied from 7-18, the correlation at lag 12 corresponds to the correlation at lag 24 in the original data. The correlations at lag 1 and lag 22 are also observed before modeling, explaining the reason for the correlation. After modeling, it is shown that  these lag correlations still exist. This means that the regression analysis of this model cannot fully explain this relationship, but adding additional lag variables can resolve this. Hence, Lag1 and Lag24 are added to the original data to create an autoregressive model.
 


### Forecast of the Averaged Data + Time Related Regressors


```R
available_data = avgdata[!is.na(production)]
to_be_forecasted = avgdata[is.na(production)]

#FORECAST OF FOLLOWING MODEL
model_avg_time = lm(production~.-date-hour-month+as.factor(month)+as.factor(hour)-production,avgdata[hour>=7 & hour <=18])


to_be_forecasted_filtered <- subset(available_data,date >= '2024-02-01' & date == '2024-05-24' & hour >= 7 & hour <= 18)


predicted_production_time <- predict(model_avg_time, newdata = to_be_forecasted_filtered)


predicted_table_time <- data.frame(date = to_be_forecasted_filtered$date,
                                   hour = to_be_forecasted_filtered$hour,
                                   predicted_production_time = predicted_production_time)

predicted_table_time
```


<table class="dataframe">
<caption>A data.frame: 12 × 3</caption>
<thead>
	<tr><th></th><th scope=col>date</th><th scope=col>hour</th><th scope=col>predicted_production_time</th></tr>
	<tr><th></th><th scope=col>&lt;IDate&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>2024-05-24</td><td> 7</td><td> 3.6712138</td></tr>
	<tr><th scope=row>2</th><td>2024-05-24</td><td> 8</td><td> 6.2892178</td></tr>
	<tr><th scope=row>3</th><td>2024-05-24</td><td> 9</td><td> 7.9647440</td></tr>
	<tr><th scope=row>4</th><td>2024-05-24</td><td>10</td><td> 7.7711521</td></tr>
	<tr><th scope=row>5</th><td>2024-05-24</td><td>11</td><td> 7.3839362</td></tr>
	<tr><th scope=row>6</th><td>2024-05-24</td><td>12</td><td> 6.8908463</td></tr>
	<tr><th scope=row>7</th><td>2024-05-24</td><td>13</td><td> 5.8813940</td></tr>
	<tr><th scope=row>8</th><td>2024-05-24</td><td>14</td><td> 4.5850572</td></tr>
	<tr><th scope=row>9</th><td>2024-05-24</td><td>15</td><td> 2.8282400</td></tr>
	<tr><th scope=row>10</th><td>2024-05-24</td><td>16</td><td> 1.0585339</td></tr>
	<tr><th scope=row>11</th><td>2024-05-24</td><td>17</td><td>-0.0867286</td></tr>
	<tr><th scope=row>12</th><td>2024-05-24</td><td>18</td><td>-0.7003239</td></tr>
</tbody>
</table>



### c) Model with averaged data + time related regressors (hour and month) + lagged variables


```R
avgdata_lagged <- data.table(avgdata,lag1=c(NA,avgdata$production[1:length(avgdata$production)-1]),lag24=c(rep(NA,24),avgdata$production[1:(length(avgdata$production)-24)]))
#lag1 and lag24 added

model_avg_time_lag = lm(production~.-date-hour-month+as.factor(month)+as.factor(hour)-production,avgdata_lagged[hour>=7 & hour <=18])
summary(model_avg_time_lag) #lag1 and lag24 added
```


    
    Call:
    lm(formula = production ~ . - date - hour - month + as.factor(month) + 
        as.factor(hour) - production, data = avgdata_lagged[hour >= 
        7 & hour <= 18])
    
    Residuals:
         Min       1Q   Median       3Q      Max 
    -10.0133  -0.8247   0.1215   0.8450   8.1556 
    
    Coefficients:
                              Estimate Std. Error t value Pr(>|t|)    
    (Intercept)             -2.9364665  1.5883421  -1.849 0.064520 .  
    CSNOW                   -0.2456401  0.1204404  -2.040 0.041424 *  
    DLWRF                   -0.0088361  0.0012522  -7.056 1.82e-12 ***
    DSWRF                   -0.0015119  0.0002409  -6.276 3.62e-10 ***
    TCDC_ENTIRE             -0.0045850  0.0011110  -4.127 3.71e-05 ***
    TCDC_High_Cloud         -0.0003894  0.0008929  -0.436 0.662807    
    TCDC_Low_Cloud          -0.0014374  0.0012187  -1.179 0.238243    
    TCDC_Middle_Cloud       -0.0025834  0.0008314  -3.107 0.001893 ** 
    TMP_surface              0.0255941  0.0066468   3.851 0.000119 ***
    USRWF_surface            0.0001038  0.0005767   0.180 0.857176    
    USWRF_top_of_atmosphere  0.0005991  0.0004223   1.419 0.155989    
    lag1                     0.6249906  0.0078424  79.694  < 2e-16 ***
    lag24                    0.1376213  0.0067799  20.298  < 2e-16 ***
    as.factor(month)2        0.4224847  0.0721084   5.859 4.80e-09 ***
    as.factor(month)3        0.6567458  0.0866896   7.576 3.87e-14 ***
    as.factor(month)4        0.7627054  0.1105127   6.902 5.44e-12 ***
    as.factor(month)5        0.8659646  0.1238981   6.989 2.93e-12 ***
    as.factor(month)6        0.9816799  0.1391943   7.053 1.87e-12 ***
    as.factor(month)7        0.9839930  0.1497113   6.573 5.18e-11 ***
    as.factor(month)8        0.9664254  0.1615800   5.981 2.29e-09 ***
    as.factor(month)9        0.7042506  0.1332428   5.285 1.28e-07 ***
    as.factor(month)10       0.4720768  0.0996682   4.736 2.20e-06 ***
    as.factor(month)11       0.1671097  0.0802364   2.083 0.037301 *  
    as.factor(month)12       0.0350034  0.0739694   0.473 0.636070    
    as.factor(hour)8         0.8647542  0.0766238  11.286  < 2e-16 ***
    as.factor(hour)9         0.7599516  0.0931756   8.156 3.86e-16 ***
    as.factor(hour)10        0.4622402  0.1635483   2.826 0.004718 ** 
    as.factor(hour)11        0.2133966  0.1826521   1.168 0.242703    
    as.factor(hour)12        0.1210706  0.1963031   0.617 0.537411    
    as.factor(hour)13       -0.1125895  0.2038881  -0.552 0.580815    
    as.factor(hour)14       -0.7135410  0.2051129  -3.479 0.000506 ***
    as.factor(hour)15       -1.5604323  0.2005699  -7.780 7.94e-15 ***
    as.factor(hour)16       -2.3292552  0.1733806 -13.434  < 2e-16 ***
    as.factor(hour)17       -2.3227174  0.1513787 -15.344  < 2e-16 ***
    as.factor(hour)18       -2.0424733  0.1290284 -15.830  < 2e-16 ***
    ---
    Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
    
    Residual standard error: 1.493 on 10449 degrees of freedom
      (73 observations deleted due to missingness)
    Multiple R-squared:  0.8466,	Adjusted R-squared:  0.8461 
    F-statistic:  1696 on 34 and 10449 DF,  p-value: < 2.2e-16
    


Model 2 uses time and lagged variables to predict solar power production, achieving an adjusted R² of 84.6%. The model includes 1-hour (lag1) and 24-hour (lag24) lagged variables to capture time-dependent patterns. A linear regression model incorporating month and hour as factors predicts production between 07:00 and 18:00. Residual analysis indicates the model captures the overall trend well, though some autocorrelation remains at specific lags. This approach effectively captures the time-dependent and autocorrelated nature of solar power production.



```R
checkresiduals(model_avg_time_lag) 
pacf(model_avg_time_lag$residuals)
```


    
    	Breusch-Godfrey test for serial correlation of order up to 38
    
    data:  Residuals
    LM test = 722.81, df = 38, p-value < 2.2e-16
    



    
![png](output_38_1.png)
    



    
![png](output_38_2.png)
    


## 2) ARIMA Models


The ARIMA model's residuals are examined to ensure the model's assumptions hold. Autocorrelation (ACF) and partial autocorrelation (PACF) plots of the residuals are analyzed to check for any remaining patterns or dependencies. A roughly normal distribution of the residuals indicates the model's effectiveness, although some skewness might suggest areas for further refinement.
By incorporating both time and seasonal elements, the ARIMA model effectively captures the complex patterns in solar power production, providing robust and reliable forecasts.


### 2.a) auto.arima Model 


```R
ForecastReportAutoAr <- function(x_date) {

arima_vec <- rep(NA,24)
for (i in 0:23){
  dataf <- avgdata[date >= train_start & date < x_date & hour == i,c("date","production")]
  dataf <- ts(dataf)
  fitted=auto.arima(dataf[,'production'],seasonal = T,trace=F)
  forecasted1=forecast(fitted,h=3)
  arima_vec[i+1]<-forecasted1$mean[3]
}
return(arima_vec)
}
#reporting accuracy
accu=function(actual,forecast){
  n=length(actual)
  error=actual-forecast
  mean=mean(actual)
  sd=sd(actual)
  CV=sd/mean
  FBias=sum(error)/sum(actual)
  MAPE=sum(abs(error/actual))/n
  RMSE=sqrt(sum(error^2)/n)
  MAD=sum(abs(error))/n
  MADP=sum(abs(error))/sum(abs(actual))
  WMAPE=MAD/mean
  l=data.frame(n,mean,sd,CV,FBias,MAPE,RMSE,MAD,MADP,WMAPE)
  return(l)
}


```


```R
forecast_autoar = ForecastReportAutoAr("2024-05-24")
```

## DYNAMIC REGRESSION

## auto.arima with 1 regressor 

"TMP_surface" is one of the significant variable in regression analysis in auto.arima model.


```R
ForecastReportArimax <- function(x_date) {
arima_vec_reg <- rep(NA,24)
for(i in 0:23) {
  dataf <- avgdata[date >= train_start & date < as.Date(x_date) -2 & hour == i,c("date","production")]
  dataf <- ts(dataf)
  regressor <- avgdata[date >= train_start & date < as.Date(x_date) -2 & hour == i,c("TMP_surface")]
  fitted_reg <- auto.arima(dataf[,'production'],xreg=data.matrix(regressor))
  regforecast <- avgdata[(date==x_date & hour==i) |(date==as.Date(x_date)+1 & hour==i)|date==as.Date(x_date)+2 & hour==i,c("TMP_surface")]
  forecasted2=forecast(fitted_reg,xreg=data.matrix(regforecast),h=2)
  arima_vec_reg[i+1] <- forecasted2$mean[2]
}
return(arima_vec_reg)
}
```


```R
ForecastReportArimax1 <- function(x_date) {
arima_vec_reg <- rep(NA,24)
for(i in 0:23) {
  dataf <- avgdata[date >= train_start & date < as.Date(x_date) -2 & hour == i,c("date","production")]
  dataf <- ts(dataf)
  regressor <- avgdata[date >= train_start & date < as.Date(x_date) -2 & hour == i,c("TCDC_Middle_Cloud")]
  fitted_reg <- auto.arima(dataf[,'production'],xreg=data.matrix(regressor))
  regforecast <- avgdata[(date==x_date & hour==i) |(date==as.Date(x_date)+1 & hour==i)|date==as.Date(x_date)+2 & hour==i,c("TCDC_Middle_Cloud")]
  forecasted2=forecast(fitted_reg,xreg=data.matrix(regforecast),h=1)
  arima_vec_reg[i+1] <- forecasted2$mean[1]
}
return(arima_vec_reg)
}
```


```R
forecast_arimax1 = ForecastReportArimax1("2024-05-26")
```


```R
forecast_arimax = ForecastReportArimax("2024-05-26")
```

## auto.arima with 2 regressors

Moreover, we added "DLWRF" variable as second one to our model.


```R
ForecastReportArimax2<- function(x_date) {
arima_vec_reg2 <- rep(NA,24)
for(i in 0:23) {
  dataf <- avgdata[date >= train_start & date < as.Date(x_date)-2 & hour == i,c("date","production")]
    dataf <- ts(dataf)
    regressor <- avgdata[date >= train_start & date < as.Date(x_date)-2 & hour == i,c("DLWRF","TMP_surface")]
  fitted_reg <- auto.arima(dataf[,'production'], xreg=data.matrix(regressor))
  regforecast <- avgdata[(date==x_date & hour==i) |(date==as.Date(x_date)+1 & hour==i |date==as.Date(x_date)+2 & hour==i),c("DLWRF","TMP_surface")]
  forecasted2=forecast(fitted_reg,xreg=data.matrix(regforecast),h=1)
  arima_vec_reg2[i+1] <- forecasted2$mean[1]
}
return(arima_vec_reg2)
}
```


```R
forecast_arimax2 = ForecastReportArimax2("2024-05-24")
```


```R
round_to_5_decimal <- function(x) {
  return(round(x, 5))
}

```

## auto.arima with 6 regressors

So currently we tried "TMP_surface","DLWRF","TCDC_ENTIRE", "TCDC_High_Cloud",	"TCDC_Low_Cloud", "TCDC_Middle_Cloud" which were also significant on linear model. For the second half of the submission period, we realized our first model has lots of dicrepancies and we tried to improved it. Therefore, in one of our trials we realized this current model gives less WMAPE score than our first one. Therefore, we proceed using this model for the rest of the competition phase.


```R
ForecastReportArimax6<- function(x_date) {
arima_vec_reg2 <- rep(NA,24)
for(i in 0:23) {
  dataf <- avgdata[date >= train_start & date < as.Date(x_date)-2 & hour == i,c("date","production")]
    dataf <- ts(dataf)
    regressor <- avgdata[date >= train_start & date < as.Date(x_date)-2 & hour == i,c("TMP_surface","DLWRF","TCDC_ENTIRE", "TCDC_High_Cloud",	"TCDC_Low_Cloud", "TCDC_Middle_Cloud")]
  fitted_reg <- auto.arima(dataf[,'production'], xreg=data.matrix(regressor))
  regforecast <- avgdata[(date==x_date & hour==i) |(date==as.Date(x_date)+1 & hour==i |date==as.Date(x_date)+2 & hour==i),c("TMP_surface","DLWRF","TCDC_ENTIRE", "TCDC_High_Cloud",	"TCDC_Low_Cloud",  "TCDC_Middle_Cloud")]
  forecasted2=forecast(fitted_reg,xreg=data.matrix(regforecast),h=1)
  arima_vec_reg2[i+1] <- forecasted2$mean[1]
}
return(arima_vec_reg2)
}
```


```R
forecast_arimax6 = ForecastReportArimax6("2024-05-26")

```


```R
dataf <- avgdata[date >= train_start & date < as.Date("2024-05-23")-2 & hour == 4,c("date","production")]
regressor <- avgdata[date >= train_start & date < as.Date("2024-05-23")-2 & hour == 4,c("DLWRF","TMP_surface")]

fitted_reg <- auto.arima(dataf[,'production'], xreg=data.matrix(regressor))
regforecast <- avgdata[(date=="2024-05-23" & hour==4) |(date==as.Date("2024-05-23")+1 & hour==4 |date==as.Date("2024-05-23")+2 & hour==4),c("DLWRF","TMP_surface")]
regforecast
forecasted2=forecast(fitted_reg,xreg=data.matrix(regforecast),h=1)
forecasted2
forecasted2$mean[3]
```


<table class="dataframe">
<caption>A data.table: 3 × 2</caption>
<thead>
	<tr><th scope=col>DLWRF</th><th scope=col>TMP_surface</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>310.904</td><td>285.0480</td></tr>
	<tr><td>287.446</td><td>283.1184</td></tr>
	<tr><td>341.365</td><td>282.9460</td></tr>
</tbody>
</table>




        Point Forecast      Lo 80     Hi 80      Lo 95     Hi 95
    870     0.10069754 0.08185901 0.1195361 0.07188650 0.1295086
    871     0.10133262 0.07469092 0.1279743 0.06058766 0.1420776
    872     0.09967272 0.06704344 0.1323020 0.04977054 0.1495749



0.0996727165039056


### Accuracy of The Models


```R
avgdata$date <- as.Date(avgdata$date)

production_data <- subset(avgdata, date == as.Date("2024-05-20"))

production_values <- production_data$production
production_values
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>0</li><li>0</li><li>0</li><li>0</li><li>0.1</li><li>0.75</li><li>1.71</li><li>2.82</li><li>4.43</li><li>7.07</li><li>8.79</li><li>8</li><li>5.58</li><li>7.28</li><li>4.94</li><li>3.76</li><li>3.42</li><li>1.28</li><li>0.23</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li></ol>




```R
forecast_arimax6 = ForecastReportArimax6("2024-05-20")
forecast_arimax2 = ForecastReportArimax2("2024-05-20")
forecast_arimax1 = ForecastReportArimax1("2024-05-20")
forecast_arimax = ForecastReportArimax("2024-05-20")
forecast_autoar = ForecastReportAutoAr("2024-05-20")
accu(production_values, forecast_arimax6)
accu(production_values, forecast_arimax2)
accu(production_values, forecast_arimax1)
accu(production_values, forecast_arimax)
accu(production_values, forecast_autoar)
```


<table class="dataframe">
<caption>A data.frame: 1 × 10</caption>
<thead>
	<tr><th scope=col>n</th><th scope=col>mean</th><th scope=col>sd</th><th scope=col>CV</th><th scope=col>FBias</th><th scope=col>MAPE</th><th scope=col>RMSE</th><th scope=col>MAD</th><th scope=col>MADP</th><th scope=col>WMAPE</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>24</td><td>2.506667</td><td>3.00424</td><td>1.1985</td><td>-0.03116658</td><td>NaN</td><td>0.9474598</td><td>0.5520537</td><td>0.2202342</td><td>0.2202342</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A data.frame: 1 × 10</caption>
<thead>
	<tr><th scope=col>n</th><th scope=col>mean</th><th scope=col>sd</th><th scope=col>CV</th><th scope=col>FBias</th><th scope=col>MAPE</th><th scope=col>RMSE</th><th scope=col>MAD</th><th scope=col>MADP</th><th scope=col>WMAPE</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>24</td><td>2.506667</td><td>3.00424</td><td>1.1985</td><td>0.009250146</td><td>NaN</td><td>0.8871042</td><td>0.5114421</td><td>0.2040328</td><td>0.2040328</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A data.frame: 1 × 10</caption>
<thead>
	<tr><th scope=col>n</th><th scope=col>mean</th><th scope=col>sd</th><th scope=col>CV</th><th scope=col>FBias</th><th scope=col>MAPE</th><th scope=col>RMSE</th><th scope=col>MAD</th><th scope=col>MADP</th><th scope=col>WMAPE</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>24</td><td>2.506667</td><td>3.00424</td><td>1.1985</td><td>-0.05661767</td><td>NaN</td><td>0.8351183</td><td>0.5308169</td><td>0.2117621</td><td>0.2117621</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A data.frame: 1 × 10</caption>
<thead>
	<tr><th scope=col>n</th><th scope=col>mean</th><th scope=col>sd</th><th scope=col>CV</th><th scope=col>FBias</th><th scope=col>MAPE</th><th scope=col>RMSE</th><th scope=col>MAD</th><th scope=col>MADP</th><th scope=col>WMAPE</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>24</td><td>2.506667</td><td>3.00424</td><td>1.1985</td><td>-0.2412262</td><td>NaN</td><td>1.112983</td><td>0.6557916</td><td>0.261619</td><td>0.261619</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A data.frame: 1 × 10</caption>
<thead>
	<tr><th scope=col>n</th><th scope=col>mean</th><th scope=col>sd</th><th scope=col>CV</th><th scope=col>FBias</th><th scope=col>MAPE</th><th scope=col>RMSE</th><th scope=col>MAD</th><th scope=col>MADP</th><th scope=col>WMAPE</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>24</td><td>2.506667</td><td>3.00424</td><td>1.1985</td><td>-0.1601362</td><td>NaN</td><td>1.008241</td><td>0.5819382</td><td>0.2321562</td><td>0.2321562</td></tr>
</tbody>
</table>



## AIC BIC


```R
ForecastReportArimax2_AIC <- function(x_date) {
  arima_vec_reg2 <- rep(NA, 24)
  aic_values <- rep(NA, 24)
  bic_values <- rep(NA, 24)
  
  for(i in 0:23) {
    dataf <- avgdata[date >= train_start & date < as.Date(x_date)-2 & hour == i, c("date", "production")]
    dataf <- ts(dataf[, "production"])  # Ensure 'dataf' is a time series of production
    regressor <- avgdata[date >= train_start & date < as.Date(x_date)-2 & hour == i, c("DLWRF", "TMP_surface")]
    
    fitted_reg <- auto.arima(dataf, xreg = data.matrix(regressor))
    
    # Store AIC and BIC values
    aic_values[i + 1] <- AIC(fitted_reg)
    bic_values[i + 1] <- BIC(fitted_reg)
    
    regforecast <- avgdata[(date == x_date & hour == i) | 
                           (date == as.Date(x_date) + 1 & hour == i) | 
                           (date == as.Date(x_date) + 2 & hour == i), 
                           c("DLWRF", "TMP_surface")]
    forecasted2 <- forecast(fitted_reg, xreg = data.matrix(regforecast), h = 1)
    arima_vec_reg2[i + 1] <- forecasted2$mean[1]
  }
  
  return(list(forecast = arima_vec_reg2, AIC = aic_values, BIC = bic_values))
}

```


```R
ForecastReportArimax2_AIC("2024-05-20")
```


<dl>
	<dt>$forecast</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>0</li><li>0</li><li>0</li><li>0</li><li>0.0404457152594016</li><li>0.686810373253903</li><li>2.46616872987695</li><li>5.1187538957535</li><li>6.29437949315316</li><li>7.30249150281727</li><li>7.12213086726937</li><li>6.20369229111642</li><li>5.85770562034897</li><li>5.82228366353765</li><li>4.8673495792197</li><li>4.18936521937703</li><li>2.39423075205666</li><li>1.10016510709738</li><li>0.137341483395275</li><li>0.000196932208285848</li><li>0</li><li>0</li><li>0</li><li>0</li></ol>
</dd>
	<dt>$AIC</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>-Inf</li><li>-Inf</li><li>-Inf</li><li>-Inf</li><li>-5071.72021909841</li><li>-1311.6987808597</li><li>1492.34557530149</li><li>3017.8491031546</li><li>3527.69791251046</li><li>3765.80688725449</li><li>3826.91738213522</li><li>3793.32390288214</li><li>3791.7758624202</li><li>3859.76736562764</li><li>3769.71850387985</li><li>3423.96805026461</li><li>2972.75078317834</li><li>1938.99745529411</li><li>148.679301824991</li><li>-9312.78590457353</li><li>-Inf</li><li>-Inf</li><li>-Inf</li><li>-Inf</li></ol>
</dd>
	<dt>$BIC</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>-Inf</li><li>-Inf</li><li>-Inf</li><li>-Inf</li><li>-5052.66930107069</li><li>-1292.64324122545</li><li>1516.16499984431</li><li>3055.95093921005</li><li>3556.28122196183</li><li>3789.6263117973</li><li>3865.02846140371</li><li>3826.67917571961</li><li>3815.58950995486</li><li>3878.82290526189</li><li>3793.53792842266</li><li>3447.78169779927</li><li>2996.57020772115</li><li>1962.81687983692</li><li>167.734841459241</li><li>-9298.49078764318</li><li>-Inf</li><li>-Inf</li><li>-Inf</li><li>-Inf</li></ol>
</dd>
</dl>



# Results, Conclusions and Future Work


We were asked to evaluate our models based on WMAPE (Weighted Mean Absolute Percentage Error) metric where weights are the mean of the actual data. Our test dates are between February 1 and May 15 2024. During the submission period we used "Model with averaged data + time related regressors (hour and month) + lagged variables" model which used for the first half of the competition. However, through the end of first week, our WMAPE score gets higher than what we expected, therefore we examined more and come up with new model with we think is more suitable. So, for the second half of the competition phase we used auto.arima with 6 regressor. To evaluate the models, we also compared the models developed with naive model, which was basically two days lagged data.

Although our model performed well in predicting solar power production, there are several areas for improvement and further research. Firstly, more advanced analysis techniques can be used together. Adding external regressors and exploring different ARIMA models might yield better results. Moreover, analyzing critical hours with very low or zero production can provide insights into refining the model to handle such cases more effectively. So the times that at the beginning we discarded might be also added. Additionally, identifying other relevant parameters for correlation, such as wind speed, atmospheric pressure, and humidity, could provide more comprehensive insights and improve the model's predictive power. However, it is important to not fall into overpredicting side of the modelling as well. From next tables, submitted and actual data can be found. Even though some issues has been gone through with submission of 14th of May.

MAY 14TH

| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.070 |
| 05:00 |                0.000 |       0.960 |
| 06:00 |                2.998 |       2.590 |
| 07:00 |                5.310 |       4.140 |
| 08:00 |                6.489 |       7.600 |
| 09:00 |                6.421 |       8.830 |
| 10:00 |                6.707 |       7.440 |
| 11:00 |                7.203 |       5.840 |
| 12:00 |                7.455 |       7.780 |
| 13:00 |                6.702 |       9.640 |
| 14:00 |                5.148 |       9.700 |
| 15:00 |                3.908 |       7.820 |
| 16:00 |                2.496 |       4.550 |
| 17:00 |                1.741 |       1.330 |
| 18:00 |                1.416 |       0.140 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |            0.000 |      0.000 |





MAY 15TH

| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.080 |
| 05:00 |                0.000 |       0.840 |
| 06:00 |                3.341 |       2.940 |
| 07:00 |                5.947 |       6.580 |
| 08:00 |                7.696 |       9.130 |
| 09:00 |                7.990 |       9.820 |
| 10:00 |                8.194 |       9.870 |
| 11:00 |                8.054 |       9.820 |
| 12:00 |                7.589 |       7.920 |
| 13:00 |                6.350 |       7.180 |
| 14:00 |                4.436 |       6.000 |
| 15:00 |                1.816 |       3.110 |
| 16:00 |                0.573 |       2.500 |
| 17:00 |                0.094 |       0.830 |
| 18:00 |                0.000 |       0.280 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 | |
| 23:00 |                0.000 |       0.000 |













MAY 16TH
| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.040 |
| 05:00 |                0.000 |       0.600 |
| 06:00 |                0.000 |       2.890 |
| 07:00 |                4.279 |       6.450 |
| 08:00 |                7.112 |       8.390 |
| 09:00 |                8.886 |       8.390 |
| 10:00 |                8.733 |       2.820 |
| 11:00 |                8.173 |       4.960 |
| 12:00 |                7.067 |       5.520 |
| 13:00 |                6.107 |       8.890 |
| 14:00 |                5.132 |       9.500 |
| 15:00 |                3.513 |       5.320 |
| 16:00 |                1.081 |       2.880 |
| 17:00 |                0.077 |       1.270 |
| 18:00 |                0.427 |       0.160 |
| 19:00 |                0.376 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.
:00 |               0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |











MAY 17TH

| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.040 |
| 05:00 |                0.000 |       0.760 |
| 06:00 |                4.406 |       2.430 |
| 07:00 |                7.345 |       4.230 |
| 08:00 |                9.074 |       5.460 |
| 09:00 |                8.753 |       9.420 |
| 10:00 |                8.573 |       8.640 |
| 11:00 |                7.906 |       4.900 |
| 12:00 |                6.691 |       6.710 |
| 13:00 |                5.361 |       7.890 |
| 14:00 |                3.564 |       5.080 |
| 15:00 |                1.024 |       6.780 |
| 16:00 |                0.082 |       3.310 |
| 17:00 |                0.405 |       1.500 |
| 18:00 |                0.338 |       0.180 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 
         0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |













MAY 18TH

| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.150 |
| 05:00 |                0.000 |       0.980 |
| 06:00 |                3.541 |       2.830 |
| 07:00 |                6.382 |       5.810 |
| 08:00 |                8.185 |       8.530 |
| 09:00 |                8.320 |       9.800 |
| 10:00 |                8.430 |       9.830 |
| 11:00 |                8.283 |       9.830 |
| 12:00 |                7.848 |       9.640 |
| 13:00 |                6.690 |       9.780 |
| 14:00 |                4.815 |       9.280 |
| 15:00 |                2.958 |       7.170 |
| 16:00 |                1.713 |       4.160 |
| 17:00 |                1.065 |       1.310 |
| 18:00 |                0.000 |       0.200 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |        0.00 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |









MAY 19TH

| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.000 |
| 05:00 |                0.000 |       0.850 |
| 06:00 |                2.814 |       3.380 |
| 07:00 |                5.591 |       6.460 |
| 08:00 |                7.461 |       9.050 |
| 09:00 |                8.117 |       8.250 |
| 10:00 |                8.070 |       8.750 |
| 11:00 |                7.818 |       9.880 |
| 12:00 |                7.409 |       8.780 |
| 13:00 |                6.431 |       9.780 |
| 14:00 |                4.702 |       7.410 |
| 15:00 |                2.656 |       4.200 |
| 16:00 |                1.106 |       2.790 |
| 17:00 |                0.537 |       1.000 |
| 18:00 |                0.000 |       0.070 |
| 19:00 |               0.000        0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |


MAY 20TH

| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.100 |
| 05:00 |                0.000 |       0.750 |
| 06:00 |                2.384 |       1.710 |
| 07:00 |                5.266 |       2.820 |
| 08:00 |                6.949 |       4.430 |
| 09:00 |                7.459 |       7.070 |
| 10:00 |                7.245 |       8.790 |
| 11:00 |                6.848 |       8.000 |
| 12:00 |                6.193 |       5.580 |
| 13:00 |                5.078 |       7.280 |
| 14:00 |                3.569 |       4.940 |
| 15:00 |                1.856 |       3.760 |
| 16:00 |                0.524 |       3.420 |
| 17:00 |                0.071 |       1.280 |
| 18:00 |                0.000 |       19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |












MAY 21TH
| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.090 |
| 05:00 |                0.000 |       0.720 |
| 06:00 |                3.775 |       2.850 |
| 07:00 |                6.555 |       5.880 |
| 08:00 |                8.410 |       8.420 |
| 09:00 |                8.727 |       7.730 |
| 10:00 |                8.779 |       5.260 |
| 11:00 |                8.451 |       5.000 |
| 12:00 |                7.592 |       3.950 |
| 13:00 |                5.878 |       7.760 |
| 14:00 |                3.704 |       8.100 |
| 15:00 |                1.686 |       4.670 |
| 16:00 |                0.386 |       3.550 |
| 17:00 |                0.000 |       1.490 |
            0.000 |       0.210 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |












MAY 22TH


| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.070 |
| 05:00 |                0.000 |       0.590 |
| 06:00 |                4.843 |       2.920 |
| 07:00 |                7.758 |       6.240 |
| 08:00 |                9.476 |       8.940 |
| 09:00 |                9.121 |       9.860 |
| 10:00 |                9.095 |       9.850 |
| 11:00 |                8.936 |       9.830 |
| 12:00 |                8.524 |       9.910 |
| 13:00 |                7.523 |       9.830 |
| 14:00 |                5.793 |       9.390 |
| 15:00 |                4.095 |       6.460 |
| 16:00 |                2.752 |       3.120 |
| 17:00 |               2.045 |       0.970 |
| 18:00 |                0.000 |       0.080 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |

MAY 23TH

| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.000 |       0.070 |
| 05:00 |                0.000 |       1.000 |
| 06:00 |                4.445 |       2.620 |
| 07:00 |                7.496 |       5.900 |
| 08:00 |                9.442 |       8.500 |
| 09:00 |                9.505 |       9.770 |
| 10:00 |                9.437 |       9.850 |
| 11:00 |                9.050 |       9.680 |
| 12:00 |                8.437 |       9.400 |
| 13:00 |                7.368 |       8.190 |
| 14:00 |                5.546 |       8.250 |
| 15:00 |                3.134 |       4.990 |
| 16:00 |                1     2.80|
| 17:00 |                0.898 |       0.860 |
| 18:00 |                0.475 |       0.090 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |









MAY 24th


| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.090 |       0.000 |
| 05:00 |                0.755 |       0.020 |
| 06:00 |                2.639 |       0.020 |
| 07:00 |                5.058 |       2.490 |
| 08:00 |                6.815 |       2.430 |
| 09:00 |                7.276 |       4.890 |
| 10:00 |                6.668 |       2.770 |
| 11:00 |                6.662 |       5.210 |
| 12:00 |                5.883 |       7.210 |
| 13:00 |                6.292 |       5.740 |
| 14:00 |                5.184 |       2.260 |
| 15:00 |                3.395 |    0 |
| 160 |                2.573 |       2.810 |
| 17:00 |                1.123 |       1.000 |
| 18:00 |                0.142 |       0.070 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |








MAY 25th


| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.069 |       0.010 |
| 05:00 |                0.722 |       0.600 |
| 06:00 |                2.577 |       0.900 |
| 07:00 |                3.849 |       0.820 |
| 08:00 |                4.372 |       1.710 |
| 09:00 |                4.329 |       3.570 |
| 10:00 |                4.109 |       2.400 |
| 11:00 |                4.363 |       2.650 |
| 12:00 |                3.583 |       6.400 |
| 13:00 |                3.991 |       8.200 |
| 14:00 |                4.335 |       5.750 |0 |              3.529 |       5.470 |
| 16:00 |                2.327 |       3.780 |
| 17:00 |                0.915 |       0.690 |
| 18:00 |                0.137 |       0.240 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |








MAY 26th


| Hours | Submitted Prediction | Actual Data |
|-------|----------------------|-------------|
| 00:00 |                0.000 |       0.000 |
| 01:00 |                0.000 |       0.000 |
| 02:00 |                0.000 |       0.000 |
| 03:00 |                0.000 |       0.000 |
| 04:00 |                0.085 |       0.090 |
| 05:00 |                0.780 |       0.580 |
| 06:00 |                2.692 |       2.970 |
| 07:00 |                5.840 |       4.600 |
| 08:00 |                8.782 |       8.220 |
| 09:00 |                9.746 |       7.520 |
| 10:00 |                9.213 |       8.070 |
| 11:00 |                9.035 |       7.280 |
| 12:00 |                8.757 |       9.320 |
| 13:00 |                8.533 |       9.450 |
| 14:00 |                7.668 |       7.410 |
| 15:00 |                5.040 |       5.250 |
| 16:00 |                2.858 |       1.530 |
| 17:00 |                1.015 |       0.640 |
| 18:00 |                0.159 |       0.190 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |

               7.668 |       7.410 |
| 15:00 |                5.040 |       5.250 |
| 16:00 |                2.858 |       1.530 |
| 17:00 |                1.015 |       0.640 |
| 18:00 |                0.159 |       0.190 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |

 2.858 |       1.530 |
| 17:00 |                1.015 |       0.640 |
| 18:00 |                0.159 |       0.190 |
| 19:00 |                0.000 |       0.000 |
| 20:00 |                0.000 |       0.000 |
| 21:00 |                0.000 |       0.000 |
| 22:00 |                0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |
         0.000 |       0.000 |
| 23:00 |                0.000 |       0.000 |
     0.000 |       0.000 |



```R

```
